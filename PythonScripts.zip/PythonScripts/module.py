import random

def multiply():
	return random.randint(1,6)

	
