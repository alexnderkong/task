first = input("What is your first name? ")
last  = input("What is your last name? ")

print("Hello " + first, last)