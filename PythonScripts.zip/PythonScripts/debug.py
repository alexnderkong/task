"""import pdb

a = "aaa"
pdb.set_trace()
b = "bbb"
c = "ccc"

final = a + b + c 
print(final)"""

user_funds = 10.31
item_price = ["burger"]

if item_price < user_funds:
	print("you dont have enough")
elif item_price == user_funds:
	print("Exact amount")
elif item_price > user_funds:
	print("sorry not enough")