sports = ['football','rugby','cricket','darts']
sports.append('basketball')
sports.append('baseball')
sports.append('golf')
sports.insert(0,'softball')
del sports[4]
print(sports[0:5])