word1 = input("Enter first word: ")
word2 = input ("Enter second word: ")
score = 0
this_list = []

print("length of word One:", len(word1))
print("length of word Two:", len(word2))
if len(word1) <= len(word2):
	print("Cannot be done")

for char in word1:

	if char in word2:
		score +=1

print("Amount Repeated is:")
print(score)

if score == len(word1)-1:
	print("Could be possible")

	for char in word1 and word2:

		this_list.append(char)
		print(this_list)
else:
	print("not possible")