number1 = input("Enter Whole Number: ")
number2 = input("Enter decimal Number: ")

integer_number = int(number1)
float_number = float(number2)
round_number = int(round(float_number))

print(number1)
print(number2)
print(round_number)