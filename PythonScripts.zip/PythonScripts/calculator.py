print("Do you want to use the calculator?")
print("1 - Yes")
print("2 - No")
prog = int(input("Use or close? "))

print("Calculator")
print("1 - Addition")
print("2 - Subtraction")
print("3 - Multiplication")
print("4 - Division")

while prog == 1:

	option = int(input("What would you like to do? "))

	if option == 1 :
		num1 = int(input("Pick a First number "))
		num2 = int(input("Pick a Second number "))
		sum = num1 + num2
		print(sum)

	elif option == 2 :
		num1 = int(input("Pick a First number "))
		num2 = int(input("Pick a Second number "))
		sum = num1 - num2
		print(sum)

	elif option == 3 :
		num1 = int(input("Pick a First number "))
		num2 = int(input("Pick a Second number "))
		sum = num1 * num2
		print(sum)

	elif option == 4 :
		num1 = int(input("Pick a First number "))
		num2 = int(input("Pick a Second number "))
		sum = num1 / num2
		print(sum)

	else:
		print("Invalid Entry")
	prog = int(input("Start Again or close? "))

else:

	print("1 = Start Again")
	print("2 = Close")
	prog = int(input("Start Again or close? "))