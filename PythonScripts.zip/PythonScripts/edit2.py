file = open("filename.txt","r+")

file.seek(0)

line = "Alexander"

file.write(line)
file.write("\n")
file.close()