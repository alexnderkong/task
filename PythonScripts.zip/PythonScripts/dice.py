import random

def multiply():
	return random.randint(1,100)

for i in range(2):
	print(multiply())

	
