invest = 100
year = 0
interest = 0.1

while invest <=1000:
	year+=1
	invest = round(invest*interest+invest,2)
	print("Year ",year,"£",invest)
