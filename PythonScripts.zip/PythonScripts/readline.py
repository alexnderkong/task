file = open("filename.txt","w")

file.write("Man City \n" )
file.write("Liverpool \n")
file.write("Chelsea \n")
file.write("Man Utd \n")
file.write("Arsenal \n")

file.close()

file = open("filename.txt","r")
file.readline()
file.readline()
file.read(1)
print(file.read(2))

file.close()