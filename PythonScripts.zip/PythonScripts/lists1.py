string = list(range(51))
del string[0]
print(string)

string1=list(range(51,61))
string.extend(string1)


print(string)
print(string[1:51:2])
print(string[2:51:3])