word1 = input("Enter a word: ")
vowel = "aeiou" 
count = 0

for char in word1:

	if char in vowel:
		count+=1
		print(count)

print("The final count is ", count)

