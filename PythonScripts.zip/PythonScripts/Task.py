import random

prizes = {
	"a":1,
	"b":3,
	"c":3,
	"d":2,
	"e":1,
	"f":4,
	"g":2,
	"h":4,
	"i":1,
	"j":8,
	"k":5,
	"l":1,
	"m":3,
	"n":1,
	"o":1,
	"p":3,
	"q":10,
	"r":1,
	"s":1,
	"t":1,
	"u":1,
	"v":4,
	"w":4,
	"x":8,
	"y":4,
	"z":10
}

again = input("Would you like to play?: ")

grand_total = 0

while  again == "yes" or again == "Yes":
	abc = "abcdefghijklmnopqrstuvwxyz"

	p1word = []

	for let in range(0,7):
		num2let = random.randint(0,25)
		lett = abc[num2let]
		p1word.append(lett)

	print(p1word)

	word = input("Please input your word: ")

	total = 0
	for char in word:
		print(prizes[char])
		total += prizes[char]
		grand_total += prizes[char]

	print("Your total is: " ,total)

	again = input("Would you like to play again?")

print("Your Grand total is..." ,grand_total)
print("Thank for playing the game")