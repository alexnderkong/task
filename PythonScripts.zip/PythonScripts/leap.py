leap = int(input("Enter your year: "))

if leap % 4 == 0: 
	if leap % 400 == 0 or leap % 100 != 0:
		print(leap, "Is a leap year!")
	else:
		print(leap, "Is not a leap year!")
else:
	print(leap, "Is not a leap year!")

