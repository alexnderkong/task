equation = "2 + 2 ="
answer = 4 
print (equation, answer)

output = equation + " " + str(answer)
print(output)

print("alex \n alex")