import dice

def roll():
	print(dice.multiply())