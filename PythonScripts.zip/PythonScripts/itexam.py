name = input("What is your name?")
homework = int(input("What was your ICT Homework score? "))
assessment = int(input("What was your Assessment score? "))
exam = int(input("What was your Exam score? "))

def addition(number1,number2,number3):
	score = number1 + number2 + number3
	return score


def percentage(number1,number2):
	score = number1/number2*100
	return score

print("Your overall mark was")
print(addition(homework,assessment,exam,))
print("out of 175")

print("Your grade percentage on homework was ")
print(percentage(homework,25),"%")

print("Your grade percentage on assessment was ")
print(percentage(homework,50),"%")

print("Your grade percentage on exam was ")
print(percentage(homework,100),"%")

a=percentage(homework,25)
b=percentage(assessment,50)
c=percentage(exam,100)

if (a-b-c)/3>90:
	print("A")

elif (a-b-c)/3>80:
	print("B")

elif (a-b-c)/3>70:
	print("C")

OverallWeightedGrade = round(a*0.25 + b*0.35 + c*0.4,2)

print("Your overall grade percentage was")
print(OverallWeightedGrade)