file = open("filename.txt","r")

print("first line: " + file.readline())
print("first line: " + file.read())

file.close()