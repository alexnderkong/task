number1 = float(input("Please enter first number"))
number2 = float(input("Please enter second number"))

answer = number1 - number2

print(number1, '-', number2, '=', answer)