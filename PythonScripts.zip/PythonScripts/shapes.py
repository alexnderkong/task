sside = float(input("Please enter first number: "))
lside = float(input("Please enter second number: "))


area = (sside * lside)
perimeter = (sside + lside + sside + lside)

print("The area is: ",area)
print("The perimeter is ",perimeter)