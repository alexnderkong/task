import random
def multiply(a,b):
	return random.randint(a,b)

weakwords = {1:"dog", 2:"cat",3:"frog", 4:"horse",5:"alan"}
mediumwords = {1:"dustbin", 2:"rhino", 3:"tiger"}
strongupper = {1:"A", 2:"B", 3:"C"}
special = {1:"£",2:"*",3:"&"}

passwordstrength = int(input("Would you like a weak, medium or strong password? 1/2/3: "))

if passwordstrength == 1:
	print(weakwords[random.randint(1,5)])

elif passwordstrength == 2:
	print( mediumwords[random.randint(1,3)] + str(multiply(1,1000)))

elif passwordstrength == 3:
	print(strongupper[random.randint(1,3)] + str(multiply(101,1000)) + mediumwords[random.randint(1,3)] + special[random.randint(1,3)])
else: 
	print("Invalid Entry")