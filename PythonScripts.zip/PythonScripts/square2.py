for i in range(1,101):
	
	if i**2 < 2000:
		print(i, i**2)