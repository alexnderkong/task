word = input("Choose your word: ")

lives  = 10
score = 0 
chosen = []

print("length of chosen word is: ", len(word))

while lives > 0 and score < len(word):
	guess = input("Take a guess: ")
	
	for char in guess:
		if char in word:
			score +=1
			print("Your Score is ",score)
			chosen.append(char)

		else:
			lives-=1
			print("How many lives you have left: ",lives)

	print("Correct Guesses",chosen)

if score == len(word):
	print("Congratulations, You have won!")

elif lives == 0:
	print("You have died!")

print("Thank you for playing")