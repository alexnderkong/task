number1 = float(input("Please enter first number: "))
answer = number1 ** 2
print(answer)

number1 = float(input("Please enter first number: "))
number2 = float(input("Please enter second number: "))

answer = number1 ** number2 
print(answer)