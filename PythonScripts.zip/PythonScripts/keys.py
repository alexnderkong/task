numbers = {
	'Tom':5647,
	'Snappy':6786,
	'Jessie':4738,
	'Oliver':9989,
	'Bob':5556,
	'Alex':1234,
	'Kevin':2468,
	'Ben':3214,
	'Roy':1423,
	'Mitchell':6789,
	'Jake':5252,
	'Callum':1111,
	'Louis':2222,
	'Adam':4545,
	'Joe':9112,
	'Jack':4044
}

list_of_keys = list(numbers.keys())
print(list_of_keys[12:16])

list_of_keys2 = list(numbers.values())
print(list_of_keys2[1:17:2])

