import random

print("Do You Want To Play Blackjack?")
print("1 - Yes")
print("2 - No")
play = input("Yes or no")

print("Your hand is:")

def multiply():
	return random.randint(1,11)

for i in range(2):
	print(multiply())

another = int(input("Do you want another card? "))
print("1 - Yes")
print("2 - No")

if another == 1:
	for i in range(1):
		print(multiply())

else:
	print("The dealer has the following cards ")
	for i in range(2):
		print(multiply())	

