number1 = float(input("Enter First Number: "))
number2 = float(input("Enter Second Number: "))

total = number1 * number2

print(float(total))
print(int(total))

