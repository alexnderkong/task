
f = open("users.txt", "r")

#Reads all data in txt
def read():
	lines = f.readlines()
	for line in lines:
		print(line)

f = open("users.txt","a")

#user input data function
def name():
	f.seek(2)
	lines = f.readlines()
	a = lines[-7]
	convert = int(a)
	u = convert + 1
	print(u)
	uniqueID = str(u)
	first_name = input("Enter your first name: ")
	last_name = input("Enter your last name: ")
	street = input("What is your address: ")
	region = input("What is your County: ")
	postcode = input("What is your postcode: ")
	number = input("What is your phone number: ")

	f.write("\n")
	f.write(uniqueID)
	f.write("\n" + first_name + "\n" + last_name + "\n" + street + "\n" + region + "\n" + postcode + "\n" + number)


f = open("users.txt","r+")
# View allows the user to view their information
def view():
	find = input("What is your ID: " )
	find = find.rstrip()
	lines = f.readlines()
	search = [lines[0::7]]
	search = find.rstrip()
	print(search) 


	if find == search:
		show = int(search)
		show = (show -1 )* 7
		print("this is ID",search)
		line = lines[show:show+7:1]
		print(line)
		line2 = lines[show:show:1]
#copyfile creates a new file and inserts all the data
def copyfile():
	fIn = open(r"users.txt")
	fOut = open(r"newFileName.txt", "w")
	for line in fIn:
	    fOut.write(line)
	fIn.close()
	fOut.close()

#unsure how to delete and therefore not used
def update():
	find = input("What is your ID: " )
	find = find.rstrip()
	lines = f.readlines()
	search = [lines[0::7]]
	search = find.rstrip()
	print(search) 

	line_offset = []
	offset = 0
	for line in f:
		line_offset.append(offset)
		offset += len(line)
		f.seek(0)
		n = find

		file.seek(line_offset[n])
		print(n)
		del(n)

 #searches for user by name but only returns true or false so not used
def search():
	f = open("users.txt","r+")
	print("1. Name?")
	enter = print("What would you like to search? ")
	datafile = ('users.txt')
	found = False

	for line in datafile:
		a = input("Enter name")
		if a in line:
			found = True
			if True:
				print("true")

			if False: 
				print("false")
#finds if there are duplicates
def duplicates():
	with open('users.txt') as f:
		seen = set()
		for line in f:
			line_lower = line.lower()
			if line_lower in seen:
				print(line)
				found = True
			else:
				seen.add(line_lower)

print("1. Read all fields")
print("2. Add your details")
print("3. Copy File")
print("4. Search Your Details")
print("5. Check for any Duplicate")
print("6. Delete your information")

userinput = int(input("What would you like to do?"))
if userinput == 1:
	read()
if userinput == 2:
	name()
if userinput == 3:
	copyfile()
if userinput == 4:
	view()
if userinput == 5:
	duplicates()
	if True:
		print("Duplicates would be listed above")
	if False:
		print("There are no duplicates")


