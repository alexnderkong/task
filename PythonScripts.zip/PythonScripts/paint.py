room = int(input("How big is your room?"))

cheapo = room * 19.99
avg = room * 17.99
dulux = room * 25

print("The cheapest paint for your room is: ")