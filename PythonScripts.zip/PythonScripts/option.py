print("Menu")
print("1 - Add")
print("2 - Amend")
print("3 - Delete")
print("4 - Display")

menu_option = int(input("Enter Option: "))

if menu_option == 1:
	print("Option 1 - Add Selected")

if menu_option == 2:
	print("Option 2 - Amend Selected")

if menu_option == 3:
	print("Option 3 - Delete Selected")

if menu_option == 4:
	print("Option 4 - Display Selected")