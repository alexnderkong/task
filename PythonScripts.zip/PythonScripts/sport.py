file = open("filename.txt","w")

file.write("Man City")
file.write("Liverpool")
file.write("Chelsea")
file.write("Man Utd")
file.write("Arsenal")

file = open("filename.txt","r")
print(file.readline())
print(file.readline())
print(file.readline())
print(file.readline())
print(file.readline())

file.close()

file = open("filename.txt","r")
file.readline()
file.readline()
print(file.read(2))

file.close()