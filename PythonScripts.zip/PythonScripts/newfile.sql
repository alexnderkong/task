CREATE DATABASE Football

CREATE TABLE footballteams (id int auto_increment PRIMARY KEY,teamname VARCHAR(40),manager VARCHAR(40)),

INSERT INTO footballteams VALUES (
"2" , "Arsenal" , "Emery"
"3" , "Manchester United" , "Solkjaer"
"4" , "Manchester City" , "Guardiola"
"5" , "Chelsea" , "Lampard"
"6" , "Tottenham Hotspur" , "Pochettino"
"7" , "Everton" , "Silva"
"8" , "Newcastle United" , "Benitez"
"9" , "Leicester City" , "Rodgers"
"10" , "West Ham" , "Pellegrini"
)

SELECT * FROM footballteams; # shows all fields

CREATE TABLE players (id int(100),playername VARCHAR(20),position VARCHAR(20)),