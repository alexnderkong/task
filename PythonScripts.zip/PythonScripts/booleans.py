animal1 = input("Enter First Animal: ")
animal2 = input("Enter Second Animal: ")

if animal1 < animal2:
	animalname = animal1
	print("The first animal is: ",animalname)
else:
	animalname = animal2
	print("The first animal is: ",animalname)

